import 'package:flutter/material.dart';
import 'package:hrms_app/model/employee_form_model.dart';
import 'package:hrms_app/model/employee_model.dart';

class EmployeeFormViewModel extends ChangeNotifier {
  EmployeeFormViewModel();

  final EmployeeFormModel form = EmployeeFormModel();

  final personalFormKey = GlobalKey<FormState>();
  final jobFormKey = GlobalKey<FormState>();
  final contractFormKey = GlobalKey<FormState>();
  final payrollFormKey = GlobalKey<FormState>();
  final workAreaFormKey = GlobalKey<FormState>();
  final documentFormKey = GlobalKey<FormState>();

  final nameController = TextEditingController();

  final emailController = TextEditingController();

  final phoneController = TextEditingController();

  final addressController = TextEditingController();

  final salaryController = TextEditingController();

  final joiningDateController = TextEditingController();

  final dobController = TextEditingController();

  final allowanceController = TextEditingController();

  final deductionController = TextEditingController();

  final payrollRuleController = TextEditingController();

  final geoFenceController = TextEditingController();

  final skillsController = TextEditingController();

  final passportController = TextEditingController();

  final aadhaarController = TextEditingController();

  final panController = TextEditingController();

  int currentStep = 0;

  bool isLoading = false;

  String? errorMessage;

  int? departmentId;

  int? designationId;

  int? reportingManagerId;

  String status = "Active";

  String wageType = "Monthly Salary";

  bool overtime = false;

  String workArea = "Office";

  String shift = "Morning";

  bool attendanceRequired = false;

  void setLoading(bool value) {
    isLoading = value;
    notifyListeners();
  }

  void setError(String? message) {
    errorMessage = message;
    notifyListeners();
  }

  void nextStep(int totalSteps) {
    if (!validateCurrentStep()) return;

    if (currentStep < totalSteps - 1) {
      currentStep++;
      notifyListeners();
    }
  }

  void previousStep() {
    if (currentStep > 0) {
      currentStep--;
      notifyListeners();
    }
  }

  void resetStep() {
    currentStep = 0;
    notifyListeners();
  }

  bool validateCurrentStep() {
    switch (currentStep) {
      case 0:
        return personalFormKey.currentState?.validate() ?? false;

      case 1:
        return jobFormKey.currentState?.validate() ?? false;

      case 2:
        return contractFormKey.currentState?.validate() ?? true;

      case 3:
        return payrollFormKey.currentState?.validate() ?? true;

      case 4:
        return workAreaFormKey.currentState?.validate() ?? true;

      case 5:
        return documentFormKey.currentState?.validate() ?? true;

      default:
        return true;
    }
  }

  String? validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Name is required";
    }

    if (value.trim().length < 3) {
      return "Name must be at least 3 characters";
    }

    return null;
  }

  String? validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Email is required";
    }

    final emailRegex = RegExp(r'^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$');

    if (!emailRegex.hasMatch(value.trim())) {
      return "Enter a valid email";
    }

    return null;
  }

  String? validatePhone(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Phone number is required";
    }

    if (value.length != 10) {
      return "Phone number must contain 10 digits";
    }

    return null;
  }

  String? validateAddress(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Address is required";
    }

    return null;
  }

  String? validateSalary(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Salary is required";
    }

    if (double.tryParse(value) == null) {
      return "Invalid salary";
    }
    return null;
  }

  String? validateRequiredDropdown(dynamic value, String title) {
    if (value == null) {
      return "$title is required";
    }

    return null;
  }

  void setDepartment(int? value) {
    departmentId = value;
    notifyListeners();
  }

  void setDesignation(int? value) {
    designationId = value;
    notifyListeners();
  }

  void setReportingManager(int? value) {
    reportingManagerId = value;
    notifyListeners();
  }

  void setStatus(String value) {
    status = value;
    notifyListeners();
  }

  void setWorkArea(String value) {
    workArea = value;
    notifyListeners();
  }

  void setShift(String value) {
    shift = value;
    notifyListeners();
  }

  void setWageType(String value) {
    wageType = value;
    notifyListeners();
  }

  void setAttendanceRequired(bool value) {
    attendanceRequired = value;
    notifyListeners();
  }

  void setOvertime(bool value) {
    overtime = value;
    notifyListeners();
  }

  void setJoiningDate(DateTime date) {
    form.joiningDate = date;
    joiningDateController.text = date.toIso8601String().split("T").first;
    notifyListeners();
  }

  void setDateOfBirth(DateTime date) {
    form.dateOfBirth = date;
    dobController.text = date.toIso8601String().split("T").first;

    notifyListeners();
  }

  void prepareForm() {
    form.name = nameController.text.trim();
    form.email = emailController.text.trim();
    form.phone = phoneController.text.trim();
    form.address = addressController.text.trim();
    form.salary = salaryController.text.trim();
    form.departmentId = departmentId;
    form.designationId = designationId;
    form.reportingManagerId = reportingManagerId;
    form.status = status;
  }

  Map<String, dynamic> toJson() {
    prepareForm();

    return {
      "name": form.name,
      "email": form.email,
      "phone": form.phone,
      "address": form.address,
      "date_of_birth": form.dateOfBirth?.toIso8601String().split("T").first,
      "salary": form.salary,
      "joining_date": form.joiningDate?.toIso8601String().split("T").first,
      "status": form.status,
      "department": form.departmentId,
      "designation": form.designationId,
      "reporting_manager": form.reportingManagerId,
    };
  }

  void loadEmployee(EmployeeModel employee) {
    nameController.text = employee.name;
    emailController.text = employee.email;
    phoneController.text = employee.phone;
    addressController.text = employee.address;
    salaryController.text = employee.salary;
    departmentId = employee.department;
    designationId = employee.designation;
    reportingManagerId = employee.reportingManager;
    status = employee.status;

    if (employee.dateOfBirth.isNotEmpty) {
      form.dateOfBirth = DateTime.parse(employee.dateOfBirth);

      dobController.text = employee.dateOfBirth;
    }

    if (employee.joiningDate.isNotEmpty) {
      form.joiningDate = DateTime.parse(employee.joiningDate);

      joiningDateController.text = employee.joiningDate;
    }

    notifyListeners();
  }

  bool get hasChanges {
    return nameController.text.trim().isNotEmpty ||
        emailController.text.trim().isNotEmpty ||
        phoneController.text.trim().isNotEmpty ||
        addressController.text.trim().isNotEmpty ||
        salaryController.text.trim().isNotEmpty;
  }

  bool get canSubmit {
    return nameController.text.trim().isNotEmpty &&
        emailController.text.trim().isNotEmpty &&
        phoneController.text.trim().isNotEmpty &&
        departmentId != null &&
        designationId != null;
  }

  void clearForm() {
    nameController.clear();
    emailController.clear();
    phoneController.clear();
    addressController.clear();
    salaryController.clear();

    joiningDateController.clear();
    dobController.clear();

    allowanceController.clear();
    deductionController.clear();

    payrollRuleController.clear();
    geoFenceController.clear();

    skillsController.clear();

    passportController.clear();
    aadhaarController.clear();
    panController.clear();

    form.employeeCode = null;
    form.name = null;
    form.email = null;
    form.phone = null;
    form.address = null;

    form.salary = null;

    form.departmentId = null;
    form.designationId = null;
    form.reportingManagerId = null;

    form.joiningDate = null;
    form.dateOfBirth = null;

    form.status = "Active";
    departmentId = null;
    designationId = null;
    reportingManagerId = null;
    status = "Active";
    wageType = "Monthly Salary";
    workArea = "Office";
    shift = "Morning";
    overtime = false;
    attendanceRequired = false;

    currentStep = 0;
    errorMessage = null;
    isLoading = false;
    notifyListeners();
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    addressController.dispose();

    salaryController.dispose();

    joiningDateController.dispose();
    dobController.dispose();

    allowanceController.dispose();
    deductionController.dispose();

    payrollRuleController.dispose();

    geoFenceController.dispose();

    skillsController.dispose();

    passportController.dispose();
    aadhaarController.dispose();
    panController.dispose();

    super.dispose();
  }
}
