import 'package:flutter/material.dart';
import 'package:hrms_app/model/empployee_model.dart';
import 'package:hrms_app/view_model/service/employee-service.dart';


class EmployeeViewModel extends ChangeNotifier {
  final EmployeeService _employeeService = EmployeeService();

  List<EmployeeModel> _employees = [];
  List<EmployeeModel> get employees => _employees;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  Future<void> getEmployees() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _employees = await _employeeService.getEmployees();
    } catch (e) {
      _errorMessage = "Failed to load employees";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}