import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:hrms_app/model/employee_model.dart';
import 'package:hrms_app/service/employee_service.dart';

class EmployeeViewModel extends ChangeNotifier {
  final EmployeeService _employeeService = EmployeeService();

  //--------------------------------------------------
  // STATE
  //--------------------------------------------------

  List<EmployeeModel> employees = [];

  List<EmployeeModel> filteredEmployees = [];

  EmployeeModel? selectedEmployee;

  bool isLoading = false;

  String? errorMessage;

  int totalEmployees = 0;

  //--------------------------------------------------
  // SEARCH & FILTER
  //--------------------------------------------------

  String searchQuery = "";

  String selectedDepartment = "All Departments";

  //--------------------------------------------------
  // LOADING
  //--------------------------------------------------

  void setLoading(bool value) {
    isLoading = value;
    notifyListeners();
  }

  //--------------------------------------------------
  // ERROR
  //--------------------------------------------------

  void setError(String? value) {
    errorMessage = value;
    notifyListeners();
  }

  //--------------------------------------------------
  // GET EMPLOYEES
  //--------------------------------------------------

  Future<void> getEmployees() async {
    try {
      setLoading(true);

      setError(null);

      employees = await _employeeService.getEmployees();

      filteredEmployees = List.from(employees);

      totalEmployees = employees.length;
    } on DioException catch (e) {
      errorMessage = e.response?.data.toString() ?? e.message;
    } catch (e) {
      errorMessage = e.toString();
    } finally {
      setLoading(false);
    }
  }

  //--------------------------------------------------
  // GET EMPLOYEE
  //--------------------------------------------------

  Future<void> getEmployeeById(int id) async {
    try {
      setLoading(true);

      selectedEmployee =
          await _employeeService.getEmployeeById(id);
    } on DioException catch (e) {
      errorMessage =
          e.response?.data.toString() ??
          e.message;
    } catch (e) {
      errorMessage = e.toString();
    } finally {
      setLoading(false);
    }
  }
    //--------------------------------------------------
  // SEARCH
  //--------------------------------------------------

  void searchEmployee(String query) {
    searchQuery = query.toLowerCase().trim();
    _applyFilters();
  }

  //--------------------------------------------------
  // FILTER
  //--------------------------------------------------

  void filterByDepartment(String department) {
    selectedDepartment = department;
    _applyFilters();
  }

  //--------------------------------------------------
  // APPLY FILTERS
  //--------------------------------------------------

  void _applyFilters() {
    filteredEmployees = employees.where((employee) {
      final matchesDepartment =
          selectedDepartment == "All Departments" ||
          employee.department.toString() == selectedDepartment;

      final matchesSearch =
          employee.name.toLowerCase().contains(searchQuery) ||
          employee.email.toLowerCase().contains(searchQuery) ||
          employee.phone.contains(searchQuery);

      return matchesDepartment && matchesSearch;
    }).toList();

    notifyListeners();
  }

  //--------------------------------------------------
  // ADD EMPLOYEE
  //--------------------------------------------------

  Future<EmployeeModel?> addEmployee(
    Map<String, dynamic> data,
  ) async {
    try {
      setLoading(true);

      setError(null);

      final employee =
          await _employeeService.addEmployee(data);

      employees.add(employee);

      totalEmployees = employees.length;

      _applyFilters();

      return employee;
    } on DioException catch (e) {
      errorMessage =
          e.response?.data.toString() ??
          e.message;

      return null;
    } catch (e) {
      errorMessage = e.toString();

      return null;
    } finally {
      setLoading(false);
    }
  }

  //--------------------------------------------------
  // UPDATE EMPLOYEE
  //--------------------------------------------------

  Future<bool> updateEmployee(
    int id,
    Map<String, dynamic> data,
  ) async {
    try {
      setLoading(true);

      setError(null);

      await _employeeService.updateEmployee(
        id,
        data,
      );

      await getEmployees();

      return true;
    } on DioException catch (e) {
      errorMessage =
          e.response?.data.toString() ??
          e.message;

      return false;
    } catch (e) {
      errorMessage = e.toString();

      return false;
    } finally {
      setLoading(false);
    }
  }

  //--------------------------------------------------
  // DELETE EMPLOYEE
  //--------------------------------------------------

  Future<bool> deleteEmployee(int id) async {
    try {
      setLoading(true);

      setError(null);

      await _employeeService.deleteEmployee(id);

      employees.removeWhere(
        (employee) => employee.id == id,
      );

      totalEmployees = employees.length;

      _applyFilters();

      return true;
    } on DioException catch (e) {
      errorMessage =
          e.response?.data.toString() ??
          e.message;

      return false;
    } catch (e) {
      errorMessage = e.toString();

      return false;
    } finally {
      setLoading(false);
    }
  }
    //--------------------------------------------------
  // REFRESH
  //--------------------------------------------------

  Future<void> refreshEmployees() async {
    await getEmployees();
  }

  //--------------------------------------------------
  // CLEAR SELECTION
  //--------------------------------------------------

  void clearSelection() {
    selectedEmployee = null;
    notifyListeners();
  }

  //--------------------------------------------------
  // EMPLOYEE COUNTS
  //--------------------------------------------------

  int get employeeCount => employees.length;

  int get activeEmployeeCount =>
      employees.where((e) => e.status.toLowerCase() == "active").length;

  int get inactiveEmployeeCount =>
      employees.where((e) => e.status.toLowerCase() != "active").length;

  //--------------------------------------------------
  // HELPERS
  //--------------------------------------------------

  bool get hasEmployees => employees.isNotEmpty;

  bool get hasSelectedEmployee => selectedEmployee != null;

  EmployeeModel? findEmployeeById(int id) {
    try {
      return employees.firstWhere((employee) => employee.id == id);
    } catch (_) {
      return null;
    }
  }

  //--------------------------------------------------
  // RESET
  //--------------------------------------------------

  void clearData() {
    employees.clear();
    filteredEmployees.clear();

    selectedEmployee = null;

    totalEmployees = 0;

    searchQuery = "";

    selectedDepartment = "All Departments";

    errorMessage = null;

    notifyListeners();
  }

  //--------------------------------------------------
  // DISPOSE
  //--------------------------------------------------

  @override
  void dispose() {
    super.dispose();
  }
}